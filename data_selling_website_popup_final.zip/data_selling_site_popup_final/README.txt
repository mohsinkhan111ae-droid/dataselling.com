README - Popup Final Version
----------------------------
- Based on the first shiny colorful version you liked.
- Loading screen removed completely.
- Price: ₹79, UPI: 6005099281@mbk
- Get App button now shows popup: "Payment not received, please pay first."
- UTR submit + Refund button included.
- Fake withdrawal notifications included.
- WhatsApp support: https://wa.me/916005099281
